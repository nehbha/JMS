# tf-msk
Terraform deployment of an AWS VPC, MSK Cluster, (optional) ACM-PCA &amp; MSK Client

[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/troydieter/tf-msk/general)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=troydieter%2Ftf-msk&benchmark=INFRASTRUCTURE+SECURITY)
<br>
[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/troydieter/tf-msk/cis_aws)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=troydieter%2Ftf-msk&benchmark=CIS+AWS+V1.2)
<br>
[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/troydieter/tf-msk/hipaa)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=troydieter%2Ftf-msk&benchmark=HIPAA)
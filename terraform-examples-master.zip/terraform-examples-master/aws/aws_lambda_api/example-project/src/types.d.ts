declare module 'one-liner-joke';
